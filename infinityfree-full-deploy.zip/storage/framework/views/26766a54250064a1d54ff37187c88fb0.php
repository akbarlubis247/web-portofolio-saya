<?php $__env->startSection('title', 'Tambah Proyek'); ?>

<?php $__env->startSection('content'); ?>
    <div class="mb-6">
        <h1 class="text-2xl font-bold text-slate-900">➕ Tambah Proyek Baru</h1>
        <p class="text-slate-500">Isi form di bawah — preview tampil di kanan. Cukup ~1 menit!</p>
    </div>

    <form action="<?php echo e(route('admin.projects.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo $__env->make('admin.projects._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div class="flex flex-wrap gap-3 mt-6">
            <button type="submit" name="action" value="publish"
                    class="px-6 py-2.5 bg-cyan-600 text-white rounded-lg hover:bg-cyan-700 font-medium">
                ✅ Publikasikan
            </button>
            <button type="submit" name="action" value="draft"
                    class="px-6 py-2.5 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 font-medium">
                💾 Save Draft
            </button>
            <a href="<?php echo e(route('admin.projects.index')); ?>" class="px-6 py-2.5 text-slate-500 hover:text-slate-700">Batal</a>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\portofolio data analyst\web_porto_saya\resources\views/admin/projects/create.blade.php ENDPATH**/ ?>