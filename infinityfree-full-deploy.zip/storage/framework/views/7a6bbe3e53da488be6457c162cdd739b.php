<?php $__env->startSection('content'); ?>
    
    <section id="home" class="relative min-h-screen flex items-center pt-16 overflow-hidden">
        <div class="hero-glow top-20 -left-32"></div>
        <div class="hero-glow bottom-20 -right-32" style="background: radial-gradient(circle, rgba(139, 92, 246, 0.12) 0%, transparent 70%);"></div>

        <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
            <div class="grid lg:grid-cols-2 gap-12 items-center">
                <div class="reveal">
                    <p class="text-cyan-400 font-medium mb-4 tracking-wide uppercase text-sm">Hello, I'm</p>
                    <h1 class="text-4xl sm:text-5xl lg:text-6xl font-bold leading-tight mb-4">
                        <span class="gradient-text"><?php echo e($settings->name); ?></span>
                    </h1>
                    <h2 class="text-2xl sm:text-3xl text-slate-300 font-light mb-6"><?php echo e($settings->title); ?></h2>
                    <p class="text-lg text-slate-400 leading-relaxed mb-8 max-w-lg">
                        <?php echo e($settings->tagline ?? 'Passionate about data, insights, and visualization'); ?>

                    </p>
                    <div class="flex flex-wrap gap-4">
                        <a href="#projects" class="btn-primary px-6 py-3 rounded-lg text-white font-medium">
                            Lihat Proyek
                        </a>
                        <a href="#contact" class="btn-outline px-6 py-3 rounded-lg text-cyan-400 font-medium">
                            Hubungi Saya
                        </a>
                    </div>
                </div>

                
                <div class="reveal reveal-delay-2 hidden lg:block">
                    <div class="relative">
                        <div class="w-full aspect-square max-w-md mx-auto rounded-2xl border border-slate-700/50 bg-gradient-to-br from-slate-800/50 to-slate-900/80 p-8 backdrop-blur">
                            <div class="grid grid-cols-2 gap-4 h-full">
                                <div class="bg-cyan-500/10 rounded-xl p-4 border border-cyan-500/20 flex flex-col justify-end">
                                    <div class="text-3xl font-bold text-cyan-400"><?php echo e($projects->count()); ?>+</div>
                                    <div class="text-sm text-slate-400">Projects</div>
                                </div>
                                <div class="bg-violet-500/10 rounded-xl p-4 border border-violet-500/20 flex flex-col justify-end">
                                    <div class="text-3xl font-bold text-violet-400"><?php echo e(count($skills)); ?></div>
                                    <div class="text-sm text-slate-400">Skills</div>
                                </div>
                                <div class="col-span-2 bg-slate-800/50 rounded-xl p-4 border border-slate-700/30">
                                    <div class="flex items-end gap-1 h-24">
                                        <?php $__currentLoopData = [40, 65, 45, 80, 55, 90, 70]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="flex-1 bg-gradient-to-t from-cyan-500 to-cyan-400/50 rounded-t" style="height: <?php echo e($h); ?>%"></div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <p class="text-xs text-slate-500 mt-2 text-center">Data Insights Preview</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <div class="section-divider max-w-6xl mx-auto"></div>

    
    <section id="about" class="py-24">
        <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="reveal text-center mb-16">
                <h2 class="text-3xl sm:text-4xl font-bold mb-4">About <span class="gradient-text">Me</span></h2>
                <div class="w-20 h-1 bg-gradient-to-r from-cyan-500 to-violet-500 mx-auto rounded"></div>
            </div>

            <div class="grid lg:grid-cols-2 gap-12 items-center">
                <div class="reveal">
                    <div class="w-48 h-48 mx-auto lg:mx-0 rounded-2xl bg-gradient-to-br from-cyan-500/20 to-violet-500/20 border border-slate-700 flex items-center justify-center">
                        <svg class="w-24 h-24 text-cyan-400/60" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>
                        </svg>
                    </div>
                </div>
                <div class="reveal reveal-delay-1">
                    <p class="text-slate-300 leading-relaxed mb-6 text-lg">
                        <?php echo e($settings->about_bio); ?>

                    </p>
                    <div class="bg-slate-800/40 border border-slate-700/50 rounded-xl p-6">
                        <h3 class="text-cyan-400 font-semibold mb-2 flex items-center gap-2">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"/>
                            </svg>
                            Career Goal
                        </h3>
                        <p class="text-slate-400"><?php echo e($settings->career_goal); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <div class="section-divider max-w-6xl mx-auto"></div>

    
    <section id="projects" class="py-24">
        <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="reveal text-center mb-16">
                <h2 class="text-3xl sm:text-4xl font-bold mb-4">My <span class="gradient-text">Projects</span></h2>
                <p class="text-slate-400 max-w-2xl mx-auto">Kumpulan proyek analisis data yang menunjukkan kemampuan saya dalam mengolah data menjadi insight.</p>
                <div class="w-20 h-1 bg-gradient-to-r from-cyan-500 to-violet-500 mx-auto rounded mt-4"></div>
            </div>

            <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <article class="project-card reveal reveal-delay-<?php echo e(($index % 3) + 1); ?> bg-[#1a2332] border border-slate-700/50 rounded-xl overflow-hidden flex flex-col">
                        
                        <div class="aspect-video img-placeholder overflow-hidden">
                            <?php if($project->image_url): ?>
                                <img src="<?php echo e($project->image_url); ?>" alt="<?php echo e($project->title); ?>" class="w-full h-full object-cover">
                            <?php else: ?>
                                <svg class="w-16 h-16 text-slate-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/>
                                </svg>
                            <?php endif; ?>
                        </div>

                        <div class="p-6 flex flex-col flex-1">
                            <?php if($project->project_date): ?>
                                <p class="text-xs text-cyan-400 mb-1"><?php echo e($project->project_date->format('M Y')); ?></p>
                            <?php endif; ?>
                            <h3 class="text-xl font-semibold text-white mb-2"><?php echo e($project->title); ?></h3>
                            <p class="text-slate-400 text-sm mb-4 flex-1"><?php echo e(\Illuminate\Support\Str::limit($project->description, 120)); ?></p>

                            
                            <?php if($project->tools): ?>
                                <div class="flex flex-wrap gap-2 mb-4">
                                    <?php $__currentLoopData = $project->tools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tool): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="text-xs px-2 py-1 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20"><?php echo e($tool); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endif; ?>

                            <div class="flex gap-3 mt-auto">
                                <a href="<?php echo e(route('portfolio.project', $project)); ?>" class="text-sm text-cyan-400 hover:text-cyan-300 font-medium flex items-center gap-1">
                                    Detail
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8l4 4m0 0l-4 4m4-4H3"/></svg>
                                </a>
                                <?php if($project->github_link): ?>
                                    <a href="<?php echo e($project->github_link); ?>" target="_blank" rel="noopener" class="text-sm text-slate-400 hover:text-white flex items-center gap-1 ml-auto">
                                        <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.395-.135-.345-.72-1.395-1.23-1.895-.42-.405-1.02-.78-1.23-.99-.405-.33-.015-.33.015-.33.42 0 .855.195 1.23.57.405.405.54.54 1.32.54.78 0 1.335-.255 1.665-.78.45-.855 1.245-1.215 1.935-1.275.54-.045 1.05-.195 1.5-.405-.015-.39-.165-.78-.465-1.125C16.335 9.585 15.33 8.085 15.33 6.585c0-.585.21-1.14.555-1.605-.06-.135-.24-.69.06-1.44 0 0 .45-.15 1.485.57.435-.12.885-.18 1.335-.18.45 0 .9.06 1.335.18 1.035-.72 1.485-.57 1.485-.57.3.75.12 1.305.06 1.44.345.465.555 1.02.555 1.605 0 1.5-1.005 3-2.565 3.375-.3.345-.48.735-.48 1.125.39.015.78.09 1.125.24.69.285 1.335.885 1.335 1.905 0 1.365-.015 2.475-.015 2.82 0 .315.225.69.825.57A8.203 8.203 0 0024 12c0-6.63-5.37-12-12-12z"/></svg>
                                        GitHub
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-span-full text-center py-12 text-slate-500">
                        Belum ada proyek. Login ke admin untuk menambahkan.
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <div class="section-divider max-w-6xl mx-auto"></div>

    
    <section id="skills" class="py-24">
        <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="reveal text-center mb-16">
                <h2 class="text-3xl sm:text-4xl font-bold mb-4">My <span class="gradient-text">Skills</span></h2>
                <div class="w-20 h-1 bg-gradient-to-r from-cyan-500 to-violet-500 mx-auto rounded"></div>
            </div>

            <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                <?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="skill-card reveal reveal-delay-<?php echo e(($index % 3) + 1); ?> bg-[#1a2332] border border-slate-700/50 rounded-xl p-6 flex items-start gap-4">
                        <div class="w-12 h-12 rounded-lg bg-cyan-500/10 flex items-center justify-center flex-shrink-0">
                            <?php echo $__env->make('partials.skill-icon', ['icon' => $skill['icon'] ?? 'chart'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        </div>
                        <div>
                            <h3 class="font-semibold text-white mb-1"><?php echo e($skill['name']); ?></h3>
                            <p class="text-sm text-slate-400"><?php echo e($skill['detail'] ?? ''); ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

    <div class="section-divider max-w-6xl mx-auto"></div>

    
    <section id="contact" class="py-24">
        <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="reveal text-center mb-16">
                <h2 class="text-3xl sm:text-4xl font-bold mb-4">Get In <span class="gradient-text">Touch</span></h2>
                <p class="text-slate-400">Tertarik berkolaborasi? Hubungi saya melalui channel berikut.</p>
                <div class="w-20 h-1 bg-gradient-to-r from-cyan-500 to-violet-500 mx-auto rounded mt-4"></div>
            </div>

            <div class="reveal flex flex-wrap justify-center gap-6">
                <?php if($settings->email): ?>
                    <a href="mailto:<?php echo e($settings->email); ?>" class="skill-card bg-[#1a2332] border border-slate-700/50 rounded-xl px-8 py-6 flex items-center gap-4 hover:border-cyan-500/30">
                        <div class="w-12 h-12 rounded-lg bg-cyan-500/10 flex items-center justify-center">
                            <svg class="w-6 h-6 text-cyan-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
                            </svg>
                        </div>
                        <div class="text-left">
                            <p class="text-sm text-slate-500">Email</p>
                            <p class="text-white font-medium"><?php echo e($settings->email); ?></p>
                        </div>
                    </a>
                <?php endif; ?>

                <?php if($settings->whatsapp): ?>
                    <a href="https://wa.me/<?php echo e(preg_replace('/\D+/', '', $settings->whatsapp)); ?>" target="_blank" rel="noopener" class="skill-card bg-[#1a2332] border border-slate-700/50 rounded-xl px-8 py-6 flex items-center gap-4 hover:border-emerald-500/30">
                        <div class="w-12 h-12 rounded-lg bg-emerald-500/10 flex items-center justify-center">
                            <svg class="w-6 h-6 text-emerald-400" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                                <path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.45 1.33 4.95L2 22l5.28-1.39a9.9 9.9 0 004.76 1.21h.01c5.46 0 9.91-4.45 9.91-9.91S17.51 2 12.04 2zm0 18.14h-.01a8.2 8.2 0 01-4.18-1.14l-.3-.18-3.13.82.84-3.05-.2-.31a8.18 8.18 0 01-1.25-4.36c0-4.54 3.69-8.23 8.23-8.23 2.2 0 4.26.86 5.82 2.41a8.18 8.18 0 012.41 5.82c0 4.53-3.69 8.22-8.23 8.22zm4.51-6.16c-.25-.12-1.46-.72-1.69-.8-.23-.08-.39-.12-.56.12-.16.25-.64.8-.78.96-.14.16-.29.18-.54.06-.25-.12-1.04-.38-1.98-1.22-.73-.65-1.23-1.46-1.37-1.7-.14-.25-.02-.38.11-.5.11-.11.25-.29.37-.43.12-.14.16-.25.25-.41.08-.16.04-.31-.02-.43-.06-.12-.56-1.35-.77-1.85-.2-.49-.41-.42-.56-.43h-.48c-.16 0-.43.06-.66.31-.23.25-.86.84-.86 2.04s.88 2.37 1 2.53c.12.16 1.73 2.64 4.19 3.7.59.25 1.04.4 1.4.52.59.19 1.12.16 1.54.1.47-.07 1.46-.6 1.66-1.18.21-.58.21-1.08.14-1.18-.06-.11-.23-.17-.48-.29z"/>
                            </svg>
                        </div>
                        <div class="text-left">
                            <p class="text-sm text-slate-500">WhatsApp</p>
                            <p class="text-white font-medium"><?php echo e($settings->whatsapp); ?></p>
                        </div>
                    </a>
                <?php endif; ?>

                <?php if($settings->linkedin): ?>
                    <a href="<?php echo e($settings->linkedin); ?>" target="_blank" rel="noopener" class="skill-card bg-[#1a2332] border border-slate-700/50 rounded-xl px-8 py-6 flex items-center gap-4 hover:border-cyan-500/30">
                        <div class="w-12 h-12 rounded-lg bg-blue-500/10 flex items-center justify-center">
                            <svg class="w-6 h-6 text-blue-400" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 114.128 0 2.063 2.063 0 01-2.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                            </svg>
                        </div>
                        <div class="text-left">
                            <p class="text-sm text-slate-500">LinkedIn</p>
                            <p class="text-white font-medium">Connect</p>
                        </div>
                    </a>
                <?php endif; ?>

                <?php if($settings->github): ?>
                    <a href="<?php echo e($settings->github); ?>" target="_blank" rel="noopener" class="skill-card bg-[#1a2332] border border-slate-700/50 rounded-xl px-8 py-6 flex items-center gap-4 hover:border-cyan-500/30">
                        <div class="w-12 h-12 rounded-lg bg-slate-500/10 flex items-center justify-center">
                            <svg class="w-6 h-6 text-slate-300" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.395-.135-.345-.72-1.395-1.23-1.895-.42-.405-1.02-.78-1.23-.99-.405-.33-.015-.33.015-.33.42 0 .855.195 1.23.57.405.405.54.54 1.32.54.78 0 1.335-.255 1.665-.78.45-.855 1.245-1.215 1.935-1.275.54-.045 1.05-.195 1.5-.405-.015-.39-.165-.78-.465-1.125C16.335 9.585 15.33 8.085 15.33 6.585c0-.585.21-1.14.555-1.605-.06-.135-.24-.69.06-1.44 0 0 .45-.15 1.485.57.435-.12.885-.18 1.335-.18.45 0 .9.06 1.335.18 1.035-.72 1.485-.57 1.485-.57.3.75.12 1.305.06 1.44.345.465.555 1.02.555 1.605 0 1.5-1.005 3-2.565 3.375-.3.345-.48.735-.48 1.125.39.015.78.09 1.125.24.69.285 1.335.885 1.335 1.905 0 1.365-.015 2.475-.015 2.82 0 .315.225.69.825.57A8.203 8.203 0 0024 12c0-6.63-5.37-12-12-12z"/>
                            </svg>
                        </div>
                        <div class="text-left">
                            <p class="text-sm text-slate-500">GitHub</p>
                            <p class="text-white font-medium">View Profile</p>
                        </div>
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.portfolio', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/portfolio/index.blade.php ENDPATH**/ ?>