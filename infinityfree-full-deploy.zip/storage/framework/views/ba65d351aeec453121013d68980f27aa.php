<?php $__env->startSection('title', 'Projects'); ?>

<?php $__env->startSection('content'); ?>
    <div class="flex items-center justify-between mb-8">
        <div>
            <h1 class="text-2xl font-bold text-slate-900">📁 Projects</h1>
            <p class="text-slate-500">Total: <strong><?php echo e($projects->count()); ?></strong> proyek</p>
        </div>
        <a href="<?php echo e(route('admin.projects.create')); ?>" class="px-4 py-2 bg-cyan-600 text-white text-sm rounded-lg hover:bg-cyan-700 font-medium">
            ➕ Add Project
        </a>
    </div>

    <div class="admin-card overflow-hidden">
        <?php if($projects->count()): ?>
            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead class="bg-slate-50">
                        <tr class="text-left text-slate-500">
                            <th class="px-6 py-3 font-medium">Title</th>
                            <th class="px-6 py-3 font-medium">Tools</th>
                            <th class="px-6 py-3 font-medium">Date</th>
                            <th class="px-6 py-3 font-medium">Status</th>
                            <th class="px-6 py-3 font-medium">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="border-t border-slate-100 hover:bg-slate-50">
                                <td class="px-6 py-4">
                                    <p class="font-medium text-slate-900"><?php echo e($project->title); ?></p>
                                    <p class="text-xs text-slate-500 truncate max-w-xs"><?php echo e(\Illuminate\Support\Str::limit($project->description, 70)); ?></p>
                                </td>
                                <td class="px-6 py-4">
                                    <div class="flex flex-wrap gap-1">
                                        <?php $__currentLoopData = array_slice($project->tools ?? [], 0, 3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tool): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="text-xs px-2 py-0.5 bg-slate-100 rounded"><?php echo e($tool); ?></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </td>
                                <td class="px-6 py-4 text-slate-500">
                                    <?php echo e($project->project_date?->format('d M Y') ?? $project->created_at->format('d M Y')); ?>

                                </td>
                                <td class="px-6 py-4">
                                    <?php if($project->is_published): ?>
                                        <span class="px-2 py-1 text-xs rounded-full bg-green-100 text-green-700">Published</span>
                                    <?php else: ?>
                                        <span class="px-2 py-1 text-xs rounded-full bg-amber-100 text-amber-700">Draft</span>
                                    <?php endif; ?>
                                </td>
                                <td class="px-6 py-4">
                                    <div class="flex gap-3">
                                        <a href="<?php echo e(route('portfolio.project', $project)); ?>" target="_blank" class="text-slate-400 hover:text-cyan-600" title="Lihat">👁</a>
                                        <a href="<?php echo e(route('admin.projects.edit', $project)); ?>" class="text-cyan-600 hover:underline">✏️ Edit</a>
                                        <form action="<?php echo e(route('admin.projects.destroy', $project)); ?>" method="POST" onsubmit="return confirm('Hapus proyek ini?')">
                                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="text-red-500 hover:underline">❌ Delete</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="text-center py-16">
                <p class="text-slate-500 mb-4">Belum ada proyek.</p>
                <a href="<?php echo e(route('admin.projects.create')); ?>" class="text-cyan-600 hover:underline font-medium">➕ Tambah proyek pertama</a>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\portofolio data analyst\web_porto_saya\resources\views/admin/projects/index.blade.php ENDPATH**/ ?>