<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?php echo e($settings->name); ?> - <?php echo e($settings->title); ?> Portfolio">
    <title><?php echo $__env->yieldContent('title', $settings->name . ' | Data Analyst Portfolio'); ?></title>

    <link rel="icon" type="image/svg+xml" href="<?php echo e(asset('favicon.svg')); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('favicon.svg')); ?>">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/portfolio.js']); ?>
</head>
<body class="portfolio-body antialiased">
    
    <nav id="navbar" class="fixed top-0 left-0 right-0 z-50 transition-all duration-300">
        <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-16">
                <a href="#home" class="text-xl font-bold gradient-text"><?php echo e($settings->name); ?></a>

                
                <div class="hidden md:flex items-center gap-6">
                    <a href="#home" class="nav-link text-sm text-slate-300 hover:text-white">Home</a>
                    <a href="#about" class="nav-link text-sm text-slate-300 hover:text-white">About</a>
                    <a href="#projects" class="nav-link text-sm text-slate-300 hover:text-white">Projects</a>
                    <a href="#skills" class="nav-link text-sm text-slate-300 hover:text-white">Skills</a>
                    <a href="#contact" class="nav-link text-sm text-slate-300 hover:text-white">Contact</a>
                    <a href="<?php echo e(route('admin.login')); ?>" class="ml-2 px-4 py-1.5 text-sm font-medium rounded-lg border border-cyan-500/40 text-cyan-400 hover:bg-cyan-500/10 transition">
                        Login
                    </a>
                </div>

                <div class="flex md:hidden items-center gap-3">
                    <a href="<?php echo e(route('admin.login')); ?>" class="px-3 py-1.5 text-xs font-medium rounded-lg border border-cyan-500/40 text-cyan-400">Login</a>
                    <button id="mobile-toggle" class="text-slate-300 hover:text-white" aria-label="Menu">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/>
                        </svg>
                    </button>
                </div>
            </div>
        </div>
    </nav>

    
    <div id="mobile-menu" class="mobile-menu fixed inset-0 z-50 bg-[#0a0f1a]/98 md:hidden">
        <div class="flex flex-col items-center justify-center h-full gap-8">
            <button id="mobile-close" class="absolute top-6 right-6 text-slate-300" aria-label="Close">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                </svg>
            </button>
            <a href="#home" class="text-2xl text-slate-200 hover:text-cyan-400">Home</a>
            <a href="#about" class="text-2xl text-slate-200 hover:text-cyan-400">About</a>
            <a href="#projects" class="text-2xl text-slate-200 hover:text-cyan-400">Projects</a>
            <a href="#skills" class="text-2xl text-slate-200 hover:text-cyan-400">Skills</a>
            <a href="#contact" class="text-2xl text-slate-200 hover:text-cyan-400">Contact</a>
            <a href="<?php echo e(route('admin.login')); ?>" class="text-2xl text-cyan-400 hover:text-cyan-300 font-medium">Login Admin</a>
        </div>
    </div>

    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    
    <footer class="border-t border-slate-800 py-8">
        <div class="max-w-6xl mx-auto px-4 text-center">
            <p class="text-slate-500 text-sm">
                &copy; <?php echo e(date('Y')); ?> <?php echo e($settings->name); ?>. Built with Laravel.
            </p>
        </div>
    </footer>
</body>
</html>
<?php /**PATH /var/www/html/resources/views/layouts/portfolio.blade.php ENDPATH**/ ?>